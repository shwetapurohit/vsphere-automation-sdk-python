# Copyright (c) 2023 VMware, Inc. All rights reserved.
# VMware Confidential
# -*- coding: utf-8 -*-
#---------------------------------------------------------------------------
# Copyright (c) 2024 Broadcom.  All rights reserved.
# The term "Broadcom" refers to Broadcom Inc. and/or its subsidiaries.

# AUTO GENERATED FILE -- DO NOT MODIFY!
#
# vAPI stub file for package com.vmware.vcenter.namespaces.networks.nsx.
#---------------------------------------------------------------------------

"""
The ``com.vmware.vcenter.namespaces.networks.nsx_client`` module provides
classes and classes for managing NSX resources.

"""

__author__ = 'VMware, Inc.'
__docformat__ = 'restructuredtext en'

import sys
from warnings import warn

from vmware.vapi.bindings import type
from vmware.vapi.bindings.converter import TypeConverter
from vmware.vapi.bindings.enum import Enum
from vmware.vapi.bindings.error import VapiError, ThrowsClauseBuilder
from vmware.vapi.bindings.struct import VapiStruct
from vmware.vapi.bindings.stub import (
    ApiInterfaceStub, StubFactoryBase, VapiInterface)
from vmware.vapi.bindings.common import raise_core_exception
from vmware.vapi.data.validator import (UnionValidator, HasFieldsOfValidator)
from vmware.vapi.exception import CoreException
from vmware.vapi.lib.constants import TaskType
from vmware.vapi.lib.rest import OperationRestMetadata


class Ipv4Cidr(VapiStruct):
    """
    The specification for representing CIDR notation of IP range. This class
    was added in vSphere API 7.0.2.00100.

    .. tip::
        The arguments are used to initialize data attributes with the same
        names.
    """




    def __init__(self,
                 address=None,
                 prefix=None,
                ):
        """
        :type  address: :class:`str`
        :param address: The IPv4 address. This attribute was added in vSphere API
            7.0.2.00100.
        :type  prefix: :class:`long`
        :param prefix: The CIDR prefix. This attribute was added in vSphere API
            7.0.2.00100.
        """
        self.address = address
        self.prefix = prefix
        VapiStruct.__init__(self)


Ipv4Cidr._set_binding_type(type.StructType(
    'com.vmware.vcenter.namespaces.networks.nsx.ipv4_cidr', {
        'address': type.StringType(),
        'prefix': type.IntegerType(),
    },
    Ipv4Cidr,
    False,
    None))



class IPRange(VapiStruct):
    """
    The ``IPRange`` class is used to express a range of IP addresses. The IP
    address supported by this structure will depend on the IP version that is
    being used by Supervisor. 
    
    Currently, the Supervisor only supports IPv4.

    .. tip::
        The arguments are used to initialize data attributes with the same
        names.
    """




    def __init__(self,
                 address=None,
                 count=None,
                ):
        """
        :type  address: :class:`str`
        :param address: :attr:`IPRange.address` is the starting IP address of the
            ``IPRange``.
        :type  count: :class:`long`
        :param count: 
            
            :attr:`IPRange.count` is number of IP addresses in the range. 
            
            For example: 
            
            A /24 subnet will have a count of 256. 
            
            A /24 subnet with a gateway address and a broadcast address will
            have a count of 254.
        """
        self.address = address
        self.count = count
        VapiStruct.__init__(self)


IPRange._set_binding_type(type.StructType(
    'com.vmware.vcenter.namespaces.networks.nsx.IP_range', {
        'address': type.StringType(),
        'count': type.IntegerType(),
    },
    IPRange,
    False,
    None))




class StubFactory(StubFactoryBase):
    _attrs = {
    }

